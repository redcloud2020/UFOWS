package com.uni.ufow.ui;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.Toast;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.util.Log;
import com.crashlytics.android.Crashlytics;
import com.google.gson.reflect.TypeToken;
import com.uni.ufow.R;
import com.uni.ufow.config.Parameters;
import com.uni.ufow.datalayer.models.User;
import com.uni.ufow.datalayer.models.UserWrapperModel;
import com.uni.ufow.datalayer.server.MyHttpClient;
import com.uni.ufow.datalayer.server.RequestDataProvider;
import com.uni.ufow.datalayer.server.RequestModel;
import com.uni.ufow.datalayer.server.ServerResponseHandler;
import com.uni.ufow.security.SecurePreferences;

import io.fabric.sdk.android.Fabric;
import org.json.JSONException;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.nio.channels.FileChannel;

public class SplashScreen extends AppCompatActivity {

    private MyHttpClient myHttpClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        setContentView(R.layout.activity_splash_screen);

        new CopyData().execute();

    }

    public class CopyData extends AsyncTask<Void, Void, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {
            copyAssets();
            return "Done";

        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            start();
        }

    }

    private void copyAssets() {
        AssetManager assetManager = getAssets();
        String[] files = null;
        try {
            files = assetManager.list("");
        } catch (IOException e) {
            Log.e("tag", "Failed to get asset file list.", e);
        }
        if (files != null) for (String filename : files) {
            InputStream in = null;
            OutputStream out = null;
            try {
                in = assetManager.open(filename);
                File outFile = new File(TARGET_BASE_PATH, filename);
                out = new FileOutputStream(outFile);
                copyFile(in, out);
            } catch(IOException e) {
                Log.e("tag", "Failed to copy asset file: " + filename, e);
            }
            finally {
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        // NOOP
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException e) {
                        // NOOP
                    }
                }
            }
        }
    }
    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
            out.write(buffer, 0, read);
        }
        start();
    }
    final static String TARGET_BASE_PATH = Environment.getExternalStorageDirectory().getAbsolutePath()+"/osmdroid";



    private  void start(){
        if (TextUtils.isEmpty(SecurePreferences.getInstance(this).getString(Parameters.FIRST_TIME))) {


            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        } else {
            if(!TextUtils.isEmpty(SecurePreferences.getInstance(this).getString(Parameters.USER_NUMBER))) {
                if(TextUtils.isEmpty(SecurePreferences.getInstance(this).getString(Parameters.DRIVER_NUMBER))) {
                    Intent intent = new Intent(this, PickDriverActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            }else {
                Intent intent = new Intent(this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        }
    }


}
