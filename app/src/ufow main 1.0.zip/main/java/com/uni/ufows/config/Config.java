package com.uni.ufows.config;

/**
 * Created by Sammy Shwairy on 2/28/2016.
 */
public interface Config {

    String URL = "http://deerail.com/Api2";


}
